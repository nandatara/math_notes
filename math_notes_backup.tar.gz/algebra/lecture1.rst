Lecture 1: Groups
=================

A group is a set combined with an operation. 

The operation must satisfy four conditions:
* Closure
* Associativity
* Identity element
* Inverse element

An example of a group is the set of integers :math:`\mathbb{Z}` under addition. For any two elements :math:`a, b \in \mathbb{Z}`, their sum :math:`a + b` is also in :math:`\mathbb{Z}`.

.. image:: /images/pythagorean-theorem-1.svg
   :alt: Pythagoras' Theorem
   :align: center
   :width: 300px

